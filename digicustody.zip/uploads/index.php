<?php
// Prevent direct access
http_response_code(403);
exit('Access Denied');
