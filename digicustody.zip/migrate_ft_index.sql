-- Migration: Add FULLTEXT index for evidence search
-- Run this SQL to add full-text search capability

ALTER TABLE evidence ADD FULLTEXT INDEX ft_evidence_search (title, description, collection_notes);
