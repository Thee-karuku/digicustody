<?php
// ============================================================
// DigiCustody – Database Configuration
// File: config/db.php
// ============================================================

date_default_timezone_set('Africa/Nairobi');

// Load environment variables from .env file
$env_file = __DIR__ . '/../.env';
if (file_exists($env_file)) {
    $lines = file($env_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $_ENV[trim($key)] = trim($value);
        }
    }
}

define('DB_HOST', 'localhost');
define('DB_NAME', 'digicustody');
define('DB_USER', $_ENV['DB_USER'] ?? 'root');
define('DB_PASS', $_ENV['DB_PASS'] ?? '');
define('DB_CHARSET', 'utf8mb4');

define('SITE_NAME', 'DigiCustody');
define('SITE_TAGLINE', 'Secure Evidence Management Platform');
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost:8080';

$project_root = dirname(__DIR__);
$doc_root = $_SERVER['DOCUMENT_ROOT'] ?? '';
if ($doc_root && strpos($project_root, $doc_root) === 0) {
    $web_path = substr($project_root, strlen($doc_root));
} else {
    $segments = explode('/', trim($project_root, '/'));
    $web_path = '/' . end($segments);
}
$web_path = rtrim($web_path, '/');

$test_base = $scheme . '://' . $host . $web_path . '/';
$test_url = $test_base . 'health.php';
$ctx = stream_context_create(['http' => ['timeout' => 2, 'ignore_errors' => true]]);
$response = @file_get_contents($test_url, false, $ctx);
if ($response === false || (isset($http_response_header[0]) && strpos($http_response_header[0], '200') === false)) {
    if (!empty($web_path)) {
        error_log("[DigiCustody] BASE_URL sanity check failed for '{$test_base}'. health.php not found. Resetting web_path to empty.");
        $web_path = '';
    }
}
unset($ctx, $response, $http_response_header);

define('BASE_URL', $scheme . '://' . $host . $web_path . '/');
error_log("[DigiCustody] BASE_URL resolved to: " . BASE_URL);

define('UPLOAD_DIR', '/var/digicustody/evidence/');
define('UPLOAD_URL', BASE_URL . 'download.php?token=');
define('DOWNLOAD_TOKEN_EXPIRY', 4); // hours - Default 4 hours for forensic evidence security
if (!defined('SESSION_TIMEOUT')) define('SESSION_TIMEOUT', 3600);

define('GMAIL_USER', $_ENV['GMAIL_USER'] ?? '');
define('GMAIL_APP_PASSWORD', $_ENV['GMAIL_APP_PASSWORD'] ?? '');

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    error_log("DB Connection Failed: " . $e->getMessage());
    die(json_encode(['error' => 'Database connection failed. Please contact the system administrator.']));
}